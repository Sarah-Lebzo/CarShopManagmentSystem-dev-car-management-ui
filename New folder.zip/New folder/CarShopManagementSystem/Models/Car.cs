using System;
using System.ComponentModel.DataAnnotations;

namespace CarShopManagementSystem.Models
{
    public class Car
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Make { get; set; }

        [Required]
        [StringLength(100)]
        public required string Model { get; set; }

        [Required]
        public int Year { get; set; }

        [Required]
        [StringLength(50)]
        public required string Color { get; set; }

        [Required]
        [System.ComponentModel.DataAnnotations.Schema.Column(TypeName = "decimal(18,2)")]
        public decimal Price { get; set; }

        [StringLength(500)]
        public required string Description { get; set; }

        public bool IsUsed { get; set; }

        public int? Mileage { get; set; }

        [StringLength(200)]
        public required string ImageUrl { get; set; }

        public bool IsAvailable { get; set; } = true;

        public DateTime? SoldDate { get; set; }

        public DateTime DateAdded { get; set; } = DateTime.Now;
    }
}